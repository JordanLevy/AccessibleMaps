From the command-line run...

npm install
node server.js

Then visit the below URL in a Google Chrome browser...

http://localhost:3000/index.html

And try uttering the script provided to the right of the map!

